Do not pass 8. I mean, yeah I understand it's hard not to, but try at least. If you can't help yourself, whatever. I'm just saying. It might cause you problems.

If you end up completely ignoring that, here's some instructions for cleaning up your mess:

Move with A and D, or the left/right arrow keys. To select an object, left click. To throw a selected object, right click in some direction. The further you click, the faster the object will go.

Alright, there you go, have some fun or whatever.

